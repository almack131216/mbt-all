`// =============================================================================
// README.TXT
// -----------------------------------------------------------------------------
// Information about the K Elements plugin.
// =============================================================================

// =============================================================================
// TABLE OF CONTENTS
// -----------------------------------------------------------------------------
//   01. Information
// =============================================================================

// Information
// Beautiful Shortcode elements for Wordpress. Developed to work with KLEO theme.

// =============================================================================

Thank you for choosing SeventhQueen

For the latest information on the K Elements plugin, make sure to register on 
our official website: http://seventhqueen.com/support